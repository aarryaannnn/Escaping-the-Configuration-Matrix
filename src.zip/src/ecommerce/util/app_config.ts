import { CoreConfig, ICoreConfig } from "../../core/util/app_config";

// 1. Extend the parent interface with module-specific flags
export interface IECommerceConfig extends ICoreConfig {
    enable_cart_validation: boolean;
}

export class ECommerceConfig extends CoreConfig {
    // 2. Override specific base values
    public static enable_beta_feature: boolean = true; 
    
    // 3. Add brand-new, module-specific values
    public static enable_cart_validation: boolean = true;

    // NOTE: max_retries is omitted! It safely falls back to the CoreConfig value (3).
    public static getConfig(): IECommerceConfig {
        return {
            ...super.getConfig(), // Inherits defaults/fallbacks from immediate parent
            enable_beta_feature: this.enable_beta_feature, // Overridden
            enable_cart_validation: this.enable_cart_validation, // New property
        };
    }
    
    // 4. The TypeScript Type-Assertion Trick
    // Redundant at runtime, but critical to force compile-time TS intellisense for 'enable_cart_validation'
    public static async getActiveConfig(moduleName: string): Promise<IECommerceConfig> {
        return super.getActiveConfig(moduleName) as Promise<IECommerceConfig>;
    }
}