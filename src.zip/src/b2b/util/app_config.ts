import { ECommerceConfig, IECommerceConfig } from "../../ecommerce/util/app_config";

// 1. Extend the E-Commerce interface
export interface IB2BConfig extends IECommerceConfig {
    enable_bulk_discount: boolean;
}

export class B2BConfig extends ECommerceConfig {
    // 2. Override a value originally defined in Core
    public static max_retries: number = 10; 
    
    // 3. Add brand-new, B2B-specific values
    public static enable_bulk_discount: boolean = true;

    // NOTE: enable_beta_feature is omitted! It falls back to ECommerceConfig (true).
    public static getConfig(): IB2BConfig {
        return {
            ...super.getConfig(), // Inherits from ECommerceConfig
            max_retries: this.max_retries, // Overridden
            enable_bulk_discount: this.enable_bulk_discount, // New property
        };
    }
    
    // 4. The TypeScript Type-Assertion Trick
    public static async getActiveConfig(moduleName: string): Promise<IB2BConfig> {
        return super.getActiveConfig(moduleName) as Promise<IB2BConfig>;
    }
}