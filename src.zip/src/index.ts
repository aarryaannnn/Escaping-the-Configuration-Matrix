import { CoreEngine } from "./core/service/CoreEngine";

async function runDemo() {
    const engine = new CoreEngine();

    // 1. Run as Core (Uses pure base defaults)
    await engine.executeProcess("core");

    // 2. Run as ECommerce (Overrides beta feature, inherits retries)
    await engine.executeProcess("ecommerce");

    // 3. Run as B2B (Overrides retries, inherits beta feature from ECommerce)
    await engine.executeProcess("b2b");
}

runDemo().catch(console.error);