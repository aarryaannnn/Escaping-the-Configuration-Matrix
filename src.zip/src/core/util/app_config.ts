export interface ICoreConfig {
    max_retries: number;
    enable_beta_feature: boolean;
}

export class CoreConfig {
    // 1. Safe Default Base Values
    public static max_retries: number = 3;
    public static enable_beta_feature: boolean = false;

    // 2. Base Configuration Object
    public static getConfig(): ICoreConfig {
        return {
            max_retries: this.max_retries,
            enable_beta_feature: this.enable_beta_feature,
        };
    }
    
    // 3. The Dynamic Runtime Loader
    public static async getActiveConfig(moduleName: string): Promise<ICoreConfig> {
        try {
            // Include explicit .ts extension for modern dynamic imports
            const modulePath = `../../${moduleName}/util/app_config.ts`;
            const module = await import(modulePath);
            
            // Extract the exported class that has the static 'getConfig' method
            const ConfigClass = module.default || Object.values(module).find((exp: any) => typeof exp?.getConfig === 'function');
            
            if (!ConfigClass) {
                throw new Error(`No class with a static 'getConfig' method found in ${modulePath}`);
            }
            
            return ConfigClass.getConfig();
            
        } catch (error: any) {
            console.error(`[ERROR] Failed to load config for '${moduleName}':`, error.message);
            console.warn(`[WARN] Falling back to CoreConfig.`);
            
            return this.getConfig();
        }
    }
}