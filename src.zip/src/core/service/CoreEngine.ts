import { ICoreConfig, CoreConfig } from "../util/app_config";

export class CoreEngine {
    
    public async executeProcess(currentModule: string) {
        console.log(`\n--- Initializing Core Engine for: [${currentModule.toUpperCase()}] ---`);
        
        // The core logic only knows about ICoreConfig!
        // Thanks to polymorphism, it holds the child config at runtime.
        const config: ICoreConfig = await CoreConfig.getActiveConfig(currentModule);

        console.log(`Config Loaded:`, config);

        // Core logic executes cleanly based on the runtime child's state
        console.log(`Max Retries set to: ${config.max_retries}`);
        
        if (config.enable_beta_feature) {
            console.log(`[Feature Flag] Beta features are ENABLED for ${currentModule}.`);
        } else {
            console.log(`[Feature Flag] Beta features are DISABLED for ${currentModule}.`);
        }
    }
}